import { Directive } from '@angular/core';

@Directive({
  selector: '[appLazyLoad]'
})
export class LazyLoad {

  constructor() { }

}
