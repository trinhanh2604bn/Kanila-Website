import { Component } from '@angular/core';

@Component({
  selector: 'app-roya',
  imports: [],
  templateUrl: './roya.html',
  styleUrl: './roya.css',
})
export class Roya {

}
