import { Component } from '@angular/core';

@Component({
  selector: 'app-security-policy',
  imports: [],
  templateUrl: './security-policy.html',
  styleUrl: './security-policy.css',
})
export class SecurityPolicy {

}
