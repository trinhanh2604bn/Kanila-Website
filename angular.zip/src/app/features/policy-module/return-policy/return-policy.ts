import { Component } from '@angular/core';

@Component({
  selector: 'app-return-policy',
  imports: [],
  templateUrl: './return-policy.html',
  styleUrl: './return-policy.css',
})
export class ReturnPolicy {

}
