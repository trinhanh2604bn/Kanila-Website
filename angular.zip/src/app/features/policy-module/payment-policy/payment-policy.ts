import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-policy',
  imports: [],
  templateUrl: './payment-policy.html',
  styleUrl: './payment-policy.css',
})
export class PaymentPolicy {

}
