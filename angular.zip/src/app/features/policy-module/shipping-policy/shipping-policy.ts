import { Component } from '@angular/core';

@Component({
  selector: 'app-shipping-policy',
  imports: [],
  templateUrl: './shipping-policy.html',
  styleUrl: './shipping-policy.css',

})
export class ShippingPolicy {

}
