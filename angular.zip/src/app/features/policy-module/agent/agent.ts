import { Component } from '@angular/core';

@Component({
  selector: 'app-agent',
  imports: [],
  templateUrl: './agent.html',
  styleUrl: './agent.css',
})
export class Agent {

}



