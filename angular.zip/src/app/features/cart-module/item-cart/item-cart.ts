import { Component } from '@angular/core';

@Component({
  selector: 'app-item-cart',
  standalone: true,
  imports: [],
  templateUrl: './item-cart.html',
  styleUrl: './item-cart.css',
})
export class ItemCart {

}
