import { Component } from '@angular/core';

@Component({
  selector: 'app-favorite',
  imports: [],
  templateUrl: './favorite.html',
  styleUrl: './favorite.css',
})
export class Favorite {

}
