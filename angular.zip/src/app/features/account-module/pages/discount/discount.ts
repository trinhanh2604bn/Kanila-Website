import { Component } from '@angular/core';

@Component({
  selector: 'app-discount',
  imports: [],
  templateUrl: './discount.html',
  styleUrl: './discount.css',
})
export class Discount {

}
