import { Component } from '@angular/core';

@Component({
  selector: 'app-profile-user',
  standalone: true,
  imports: [],
  templateUrl: './profile-user.html',
  styleUrl: './profile-user.css',
})
export class ProfileUser {

}
