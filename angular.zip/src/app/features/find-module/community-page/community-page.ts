import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-community-page',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './community-page.html',
  styleUrl: './community-page.css',
})
export class CommunityPage {

}
